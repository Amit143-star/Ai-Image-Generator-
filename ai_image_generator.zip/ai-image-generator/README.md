# AI-Powered Image Generator

This repository contains a local, open-source text-to-image generation system using Diffusion models and a Streamlit UI.
It includes GPU/CPU paths, prompt engineering utilities, simple content filtering, watermarking, and storage/export features.

## Quickstart
1. Create and activate a virtual environment:
   ```bash
   python -m venv venv
   source venv/bin/activate   # Windows: venv\Scripts\activate
   ```
2. Install requirements:
   ```bash
   pip install -r requirements.txt
   ```
3. (Optional) Download a model or let diffusers fetch it automatically on first run. For guarded HF models, run `huggingface-cli login` first.
4. Run the Streamlit app:
   ```bash
   cd app
   streamlit run streamlit_app.py
   ```
5. Open the shown localhost URL (e.g. http://localhost:8501).

## Project structure
```
ai-image-generator/
├── README.md
├── requirements.txt
├── models/
├── app/
│   ├── streamlit_app.py
│   ├── model_loader.py
│   ├── utils.py
│   └── watermark.py
├── scripts/
│   └── download_model.sh
├── examples/
├── outputs/
└── LICENSE
```

## Notes
- This project uses open-source models (example: `runwayml/stable-diffusion-v1-5`) via `diffusers`.
- Respect licenses of model checkpoints you use.
- The included content filter is a simple heuristic — for production use integrate a stronger classifier.
