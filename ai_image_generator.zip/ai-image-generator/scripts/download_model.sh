#!/usr/bin/env bash
set -e
MODEL_ID="runwayml/stable-diffusion-v1-5"  # example; choose any open-source HF model
mkdir -p models
cd models
if [ -d "${MODEL_ID##*/}" ]; then
  echo "Model dir exists. Skipping clone."
  exit 0
fi
git clone https://huggingface.co/$MODEL_ID
echo "If the model requires authentication, run: huggingface-cli login"
