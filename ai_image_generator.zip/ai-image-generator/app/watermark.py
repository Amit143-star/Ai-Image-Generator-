from PIL import Image, ImageDraw, ImageFont

def apply_watermark(image, text="AI-generated", opacity=120, fontsize=18, margin=10):
    image = image.convert("RGBA")
    txt = Image.new("RGBA", image.size, (255,255,255,0))
    draw = ImageDraw.Draw(txt)
    try:
        font = ImageFont.truetype("arial.ttf", fontsize)
    except Exception:
        font = ImageFont.load_default()
    w, h = draw.textsize(text, font=font)
    x = image.size[0] - w - margin
    y = image.size[1] - h - margin
    draw.text((x,y), text, fill=(255,255,255,opacity), font=font)
    out = Image.alpha_composite(image, txt)
    return out.convert("RGB")
