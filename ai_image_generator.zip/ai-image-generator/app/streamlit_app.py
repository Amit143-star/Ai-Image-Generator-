import streamlit as st
from model_loader import load_pipeline
from utils import sanitize_prompt, basic_content_filter, save_image_and_metadata
from watermark import apply_watermark
from PIL import Image
import torch
import time
from io import BytesIO

st.set_page_config(page_title="AI Image Generator", layout="centered")
st.title("AI-Powered Image Generator")

model_id = st.sidebar.text_input("Model (HF ID)", value="runwayml/stable-diffusion-v1-5")
use_gpu = st.sidebar.checkbox("Use GPU (if available)", value=True)
num_images = st.sidebar.slider("Images per prompt", min_value=1, max_value=4, value=1)
num_inference_steps = st.sidebar.slider("Inference steps", min_value=20, max_value=100, value=30)
guidance_scale = st.sidebar.slider("Guidance scale", min_value=1.0, max_value=20.0, value=7.5)
style_preset = st.sidebar.selectbox("Style preset", ["photorealistic", "artistic", "cartoon", "fantasy", "none"]) 
negative_prompt = st.sidebar.text_area("Negative prompt (optional)", value="")
watermark = st.sidebar.checkbox("Apply watermark (AI-generated)", value=True)

if st.sidebar.button("Load model"):
    device = "cuda" if (use_gpu and torch.cuda.is_available()) else "cpu"
    with st.spinner(f"Loading model {model_id} on {device}..."):
        pipe = load_pipeline(model_id=model_id, device=device, torch_dtype=(torch.float16 if device=="cuda" else torch.float32))
        st.session_state["pipe"] = pipe
        st.success("Model loaded. Ready to generate.")

prompt = st.text_area("Enter prompt", value="A futuristic city at sunset, highly detailed, 4k, cinematic lighting")

if st.button("Generate"):
    prompt = sanitize_prompt(prompt)
    ok, reason = basic_content_filter(prompt)
    if not ok:
        st.error(f"Prompt rejected: {reason}")
    else:
        if "pipe" not in st.session_state:
            device = "cuda" if (use_gpu and torch.cuda.is_available()) else "cpu"
            st.info(f"Model not loaded explicitly. Loading on {device} (this may take a while)...")
            st.session_state["pipe"] = load_pipeline(model_id=model_id, device=device, torch_dtype=(torch.float16 if device=="cuda" else torch.float32))

        pipe = st.session_state["pipe"]
        progress_bar = st.progress(0)

        imgs = []
        t0 = time.time()
        for i in range(num_images):
            progress_bar.progress(int((i / max(1, num_images)) * 100))
            with st.spinner(f"Generating image {i+1}/{num_images}..."):
                result = pipe(prompt=prompt, negative_prompt=negative_prompt, num_inference_steps=num_inference_steps, guidance_scale=guidance_scale)
                image = result.images[0]
                if watermark:
                    image = apply_watermark(image)
                imgs.append(image)
                params = {
                    "num_inference_steps": num_inference_steps,
                    "guidance_scale": guidance_scale,
                    "negative_prompt": negative_prompt,
                    "style_preset": style_preset,
                }
                save_image_and_metadata(image, prompt, params)

        progress_bar.progress(100)
        t1 = time.time()
        elapsed = t1 - t0
        st.success(f"Done — generated {len(imgs)} image(s) in {elapsed:.1f}s")

        for im in imgs:
            st.image(im, use_column_width=True)
            buf = BytesIO()
            im.save(buf, format="PNG")
            st.download_button("Download PNG", data=buf.getvalue(), file_name="generated.png", mime="image/png")
