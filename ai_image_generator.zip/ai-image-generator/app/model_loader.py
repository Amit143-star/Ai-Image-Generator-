import torch
from diffusers import StableDiffusionPipeline

def load_pipeline(model_id: str = "runwayml/stable-diffusion-v1-5", device: str = None, use_auth_token: str | None = None, torch_dtype=None):
    """Load a Stable Diffusion pipeline with CPU/GPU handling."""
    if device is None:
        device = "cuda" if torch.cuda.is_available() else "cpu"

    kwargs = {}
    if torch_dtype:
        kwargs["torch_dtype"] = torch_dtype

    pipe = StableDiffusionPipeline.from_pretrained(model_id, use_auth_token=use_auth_token, **kwargs)
    pipe = pipe.to(device)

    try:
        pipe.enable_attention_slicing()
    except Exception:
        pass
    try:
        pipe.enable_xformers_memory_efficient_attention()
    except Exception:
        pass

    return pipe
