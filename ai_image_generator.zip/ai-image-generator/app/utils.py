import os
import json
from datetime import datetime
from PIL import Image
import re

ALLOWED_PROMPT_REGEX = r"^[\w\s\-\,\'\":\.\!\?()]+$"

def sanitize_prompt(prompt: str) -> str:
    return prompt.strip()

def basic_content_filter(prompt: str) -> tuple[bool,str]:
    p = prompt.lower()
    banned_keywords = ["porn", "sex", "kill", "murder", "child", "explosive", "weapon", "gun", "illicit"]
    for k in banned_keywords:
        if k in p:
            return False, f"Prompt contains disallowed keyword: {k}"
    if not re.match(ALLOWED_PROMPT_REGEX, prompt):
        return False, "Prompt contains unusual characters"
    return True, "ok"

def save_image_and_metadata(img: Image.Image, prompt: str, params: dict, out_dir: str = "../outputs") -> str:
    os.makedirs(out_dir, exist_ok=True)
    timestamp = datetime.utcnow().strftime("%Y%m%dT%H%M%SZ")
    fname_base = f"img_{timestamp}"
    img_path = os.path.join(out_dir, f"{fname_base}.png")
    img.save(img_path)
    metadata = {
        "prompt": prompt,
        "params": params,
        "timestamp": timestamp,
        "filename": os.path.basename(img_path)
    }
    meta_path = os.path.join(out_dir, f"{fname_base}.json")
    with open(meta_path, "w", encoding="utf-8") as f:
        json.dump(metadata, f, indent=2)
    return img_path
